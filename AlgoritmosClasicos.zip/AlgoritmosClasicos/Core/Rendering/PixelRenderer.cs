using System;
using System.Collections.Generic;
using System.Drawing;
using AlgoritmosClasicos.Core.Models;

namespace AlgoritmosClasicos.Core.Rendering
{
    /// <summary>
    /// Clase responsable de renderizar p�xeles como cuadrados visibles en un Graphics.
    /// Simula p�xeles l�gicos como cuadrados de tama�o configurable para mejor visualizaci�n.
    /// Esta clase es reutilizable por todos los algoritmos gr�ficos.
    /// </summary>
    public class PixelRenderer
    {
        private readonly int _pixelSize;
        private readonly Color _pixelColor;
        private readonly Brush _pixelBrush;
        private int _canvasHeight;

        /// <summary>
        /// Tama�o de cada p�xel simulado en p�xeles de pantalla.
        /// </summary>
        public int PixelSize => _pixelSize;

        /// <summary>
        /// Color utilizado para dibujar los p�xeles.
        /// </summary>
        public Color PixelColor => _pixelColor;

        /// <summary>
        /// Constructor con par�metros personalizables.
        /// </summary>
        /// <param name="pixelSize">Tama�o del p�xel simulado (por defecto 5)</param>
        /// <param name="pixelColor">Color del p�xel (por defecto Negro)</param>
        /// <param name="canvasHeight">Alto del canvas en p�xeles l�gicos (para invertir Y)</param>
        public PixelRenderer(int pixelSize = 5, Color? pixelColor = null, int canvasHeight = 80)
        {
            if (pixelSize <= 0)
                throw new ArgumentException("El tama�o del p�xel debe ser mayor a 0.", nameof(pixelSize));

            _pixelSize = pixelSize;
            _pixelColor = pixelColor ?? Color.Black;
            _pixelBrush = new SolidBrush(_pixelColor);
            _canvasHeight = canvasHeight;
        }

        /// <summary>
        /// Convierte la coordenada Y de origen inferior a origen superior (pantalla).
        /// </summary>
        private int InvertY(int y)
        {
            return _canvasHeight - 1 - y;
        }

        /// <summary>
        /// Dibuja un solo p�xel simulado.
        /// </summary>
        /// <param name="graphics">Objeto Graphics donde dibujar</param>
        /// <param name="point">Punto a dibujar</param>
        public void DrawPixel(Graphics graphics, PixelPoint point)
        {
            if (graphics == null)
                throw new ArgumentNullException(nameof(graphics));
            
            if (point == null)
                throw new ArgumentNullException(nameof(point));

            int screenY = InvertY(point.Y);
            graphics.FillRectangle(_pixelBrush, 
                point.X * _pixelSize, 
                screenY * _pixelSize, 
                _pixelSize, 
                _pixelSize);
        }

        /// <summary>
        /// Dibuja m�ltiples p�xeles simulados.
        /// </summary>
        /// <param name="graphics">Objeto Graphics donde dibujar</param>
        /// <param name="points">Lista de puntos a dibujar</param>
        public void DrawPixels(Graphics graphics, List<PixelPoint> points)
        {
            if (graphics == null)
                throw new ArgumentNullException(nameof(graphics));
            
            if (points == null)
                throw new ArgumentNullException(nameof(points));

            foreach (var point in points)
            {
                DrawPixel(graphics, point);
            }
        }

        /// <summary>
        /// Dibuja un p�xel con un color espec�fico (temporal).
        /// </summary>
        /// <param name="graphics">Objeto Graphics donde dibujar</param>
        /// <param name="point">Punto a dibujar</param>
        /// <param name="color">Color espec�fico para este p�xel</param>
        public void DrawPixel(Graphics graphics, PixelPoint point, Color color)
        {
            if (graphics == null)
                throw new ArgumentNullException(nameof(graphics));
            
            if (point == null)
                throw new ArgumentNullException(nameof(point));

            int screenY = InvertY(point.Y);
            using (var brush = new SolidBrush(color))
            {
                graphics.FillRectangle(brush, 
                    point.X * _pixelSize, 
                    screenY * _pixelSize, 
                    _pixelSize, 
                    _pixelSize);
            }
        }

        /// <summary>
        /// Dibuja una grilla (opcional) para visualizar mejor los p�xeles.
        /// </summary>
        /// <param name="graphics">Objeto Graphics donde dibujar</param>
        /// <param name="width">Ancho del canvas en p�xeles l�gicos</param>
        /// <param name="height">Alto del canvas en p�xeles l�gicos</param>
        public void DrawGrid(Graphics graphics, int width, int height)
        {
            if (graphics == null)
                throw new ArgumentNullException(nameof(graphics));

            using (var pen = new Pen(Color.LightGray, 1))
            {
                // L�neas verticales
                for (int x = 0; x <= width; x++)
                {
                    graphics.DrawLine(pen, 
                        x * _pixelSize, 0, 
                        x * _pixelSize, height * _pixelSize);
                }

                // L�neas horizontales
                for (int y = 0; y <= height; y++)
                {
                    graphics.DrawLine(pen, 
                        0, y * _pixelSize, 
                        width * _pixelSize, y * _pixelSize);
                }
            }
        }

        /// <summary>
        /// Limpia los recursos utilizados.
        /// </summary>
        public void Dispose()
        {
            _pixelBrush?.Dispose();
        }
    }
}
