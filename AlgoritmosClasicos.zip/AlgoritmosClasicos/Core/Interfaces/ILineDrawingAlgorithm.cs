using System.Collections.Generic;
using AlgoritmosClasicos.Core.Models;

namespace AlgoritmosClasicos.Core.Interfaces
{
    /// <summary>
    /// Interfaz que define el contrato para todos los algoritmos de trazado de l�neas.
    /// Implementada por DDA, Bresenham y Midpoint.
    /// </summary>
    public interface ILineDrawingAlgorithm
    {
        /// <summary>
        /// Nombre descriptivo del algoritmo.
        /// </summary>
        string Name { get; }

        /// <summary>
        /// Descripci�n breve del algoritmo y su funcionamiento.
        /// </summary>
        string Description { get; }

        /// <summary>
        /// Calcula todos los puntos p�xel necesarios para dibujar una l�nea
        /// desde el punto inicial hasta el punto final.
        /// </summary>
        /// <param name="start">Punto inicial de la l�nea</param>
        /// <param name="end">Punto final de la l�nea</param>
        /// <returns>Lista ordenada de puntos que forman la l�nea</returns>
        List<PixelPoint> CalculateLine(PixelPoint start, PixelPoint end);
    }
}
