using AlgoritmosClasicos.Core.Models;

namespace AlgoritmosClasicos.Core.Interfaces
{
    /// <summary>
    /// Interfaz que define el contrato para todos los algoritmos de recorte de l�neas.
    /// Implementada por Cohen-Sutherland, Liang-Barsky y Nicholl-Lee-Nicholl.
    /// </summary>
    public interface ILineClippingAlgorithm
    {
        /// <summary>
        /// Nombre descriptivo del algoritmo.
        /// </summary>
        string Name { get; }

        /// <summary>
        /// Descripci�n breve del algoritmo y su funcionamiento.
        /// </summary>
        string Description { get; }

        /// <summary>
        /// Recorta una l�nea contra una ventana de recorte rectangular.
        /// </summary>
        /// <param name="start">Punto inicial de la l�nea</param>
        /// <param name="end">Punto final de la l�nea</param>
        /// <param name="clipRect">Ventana de recorte</param>
        /// <returns>L�nea recortada o null si est� completamente fuera</returns>
        ClippedLine ClipLine(PixelPoint start, PixelPoint end, ClipRectangle clipRect);
    }
}
