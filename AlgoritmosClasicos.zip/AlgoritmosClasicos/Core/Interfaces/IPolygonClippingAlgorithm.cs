using AlgoritmosClasicos.Core.Models;

namespace AlgoritmosClasicos.Core.Interfaces
{
    /// <summary>
    /// Interfaz que define el contrato para todos los algoritmos de recorte de pol�gonos.
    /// Implementada por Sutherland-Hodgman, Weiler-Atherton y Cyrus-Beck.
    /// </summary>
    public interface IPolygonClippingAlgorithm
    {
        /// <summary>
        /// Nombre descriptivo del algoritmo.
        /// </summary>
        string Name { get; }

        /// <summary>
        /// Descripci�n breve del algoritmo y su funcionamiento.
        /// </summary>
        string Description { get; }

        /// <summary>
        /// Recorta un pol�gono contra un rect�ngulo de recorte.
        /// </summary>
        /// <param name="subjectPolygon">Pol�gono a recortar</param>
        /// <param name="clipRectangle">Rect�ngulo de recorte</param>
        /// <returns>Pol�gono recortado o null si est� completamente fuera</returns>
        Polygon ClipPolygon(Polygon subjectPolygon, ClipRectangle clipRectangle);
    }
}
