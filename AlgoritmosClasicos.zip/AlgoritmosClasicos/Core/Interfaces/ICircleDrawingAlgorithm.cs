using System.Collections.Generic;
using AlgoritmosClasicos.Core.Models;

namespace AlgoritmosClasicos.Core.Interfaces
{
    /// <summary>
    /// Interfaz que define el contrato para todos los algoritmos de trazado de c�rculos.
    /// Implementada por Bresenham, Incremental y DDA para c�rculos.
    /// </summary>
    public interface ICircleDrawingAlgorithm
    {
        /// <summary>
        /// Nombre descriptivo del algoritmo.
        /// </summary>
        string Name { get; }

        /// <summary>
        /// Descripci�n breve del algoritmo y su funcionamiento.
        /// </summary>
        string Description { get; }

        /// <summary>
        /// Calcula todos los puntos p�xel necesarios para dibujar un c�rculo
        /// dado un centro y un radio.
        /// </summary>
        /// <param name="center">Centro del c�rculo</param>
        /// <param name="radius">Radio del c�rculo</param>
        /// <returns>Lista ordenada de puntos que forman el c�rculo</returns>
        List<PixelPoint> CalculateCircle(PixelPoint center, int radius);
    }
}
