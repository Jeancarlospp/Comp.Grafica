using System;

namespace AlgoritmosClasicos.Core.Models
{
    /// <summary>
    /// Representa un rect�ngulo de recorte (ventana de recorte) en coordenadas de p�xeles.
    /// Utilizado en algoritmos de recorte de l�neas.
    /// </summary>
    public class ClipRectangle
    {
        /// <summary>
        /// Coordenada X m�nima (izquierda).
        /// </summary>
        public int XMin { get; }

        /// <summary>
        /// Coordenada Y m�nima (inferior).
        /// </summary>
        public int YMin { get; }

        /// <summary>
        /// Coordenada X m�xima (derecha).
        /// </summary>
        public int XMax { get; }

        /// <summary>
        /// Coordenada Y m�xima (superior).
        /// </summary>
        public int YMax { get; }

        /// <summary>
        /// Ancho del rect�ngulo.
        /// </summary>
        public int Width => XMax - XMin;

        /// <summary>
        /// Alto del rect�ngulo.
        /// </summary>
        public int Height => YMax - YMin;

        /// <summary>
        /// Constructor del rect�ngulo de recorte.
        /// </summary>
        /// <param name="xMin">Coordenada X m�nima</param>
        /// <param name="yMin">Coordenada Y m�nima</param>
        /// <param name="xMax">Coordenada X m�xima</param>
        /// <param name="yMax">Coordenada Y m�xima</param>
        public ClipRectangle(int xMin, int yMin, int xMax, int yMax)
        {
            if (xMin >= xMax)
                throw new ArgumentException("XMin debe ser menor que XMax");
            
            if (yMin >= yMax)
                throw new ArgumentException("YMin debe ser menor que YMax");

            XMin = xMin;
            YMin = yMin;
            XMax = xMax;
            YMax = yMax;
        }

        /// <summary>
        /// Verifica si un punto est� completamente dentro del rect�ngulo.
        /// </summary>
        public bool Contains(PixelPoint point)
        {
            return point.X >= XMin && point.X <= XMax &&
                   point.Y >= YMin && point.Y <= YMax;
        }

        /// <summary>
        /// Verifica si el rect�ngulo es v�lido (tiene �rea positiva).
        /// </summary>
        public bool IsValid()
        {
            return Width > 0 && Height > 0;
        }

        public override string ToString()
        {
            return $"ClipRect[({XMin},{YMin}) - ({XMax},{YMax})]";
        }
    }
}
