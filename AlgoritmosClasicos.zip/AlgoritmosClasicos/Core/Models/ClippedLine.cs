namespace AlgoritmosClasicos.Core.Models
{
    /// <summary>
    /// Representa una l�nea recortada con sus puntos de inicio y fin.
    /// Puede ser null si la l�nea est� completamente fuera de la ventana de recorte.
    /// </summary>
    public class ClippedLine
    {
        /// <summary>
        /// Punto de inicio de la l�nea recortada.
        /// </summary>
        public PixelPoint Start { get; }

        /// <summary>
        /// Punto final de la l�nea recortada.
        /// </summary>
        public PixelPoint End { get; }

        /// <summary>
        /// Indica si la l�nea es visible (est� dentro de la ventana).
        /// </summary>
        public bool IsVisible { get; }

        /// <summary>
        /// Constructor para l�nea visible recortada.
        /// </summary>
        public ClippedLine(PixelPoint start, PixelPoint end)
        {
            Start = start;
            End = end;
            IsVisible = true;
        }

        /// <summary>
        /// Constructor para l�nea no visible.
        /// </summary>
        private ClippedLine()
        {
            Start = null;
            End = null;
            IsVisible = false;
        }

        /// <summary>
        /// Crea una l�nea marcada como no visible.
        /// </summary>
        public static ClippedLine NotVisible()
        {
            return new ClippedLine();
        }

        public override string ToString()
        {
            if (!IsVisible)
                return "ClippedLine[Not Visible]";
            
            return $"ClippedLine[{Start} -> {End}]";
        }
    }
}
