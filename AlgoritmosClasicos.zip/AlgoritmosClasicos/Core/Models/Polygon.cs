using System;
using System.Collections.Generic;

namespace AlgoritmosClasicos.Core.Models
{
    /// <summary>
    /// Representa un pol�gono como una lista ordenada de v�rtices.
    /// Utilizado en algoritmos de recorte de pol�gonos.
    /// </summary>
    public class Polygon
    {
        private readonly List<PixelPoint> _vertices;

        /// <summary>
        /// Lista de v�rtices del pol�gono.
        /// </summary>
        public List<PixelPoint> Vertices => _vertices;

        /// <summary>
        /// N�mero de v�rtices en el pol�gono.
        /// </summary>
        public int VertexCount => _vertices.Count;

        /// <summary>
        /// Indica si el pol�gono est� cerrado (tiene al menos 3 v�rtices).
        /// </summary>
        public bool IsClosed => _vertices.Count >= 3;

        /// <summary>
        /// Constructor por defecto que crea un pol�gono vac�o.
        /// </summary>
        public Polygon()
        {
            _vertices = new List<PixelPoint>();
        }

        /// <summary>
        /// Constructor que crea un pol�gono con una lista de v�rtices.
        /// </summary>
        public Polygon(List<PixelPoint> vertices)
        {
            if (vertices == null)
                throw new ArgumentNullException(nameof(vertices));
            
            _vertices = new List<PixelPoint>(vertices);
        }

        /// <summary>
        /// Agrega un v�rtice al pol�gono.
        /// </summary>
        public void AddVertex(PixelPoint vertex)
        {
            if (vertex == null)
                throw new ArgumentNullException(nameof(vertex));
            
            _vertices.Add(vertex);
        }

        /// <summary>
        /// Obtiene un v�rtice en el �ndice especificado.
        /// </summary>
        public PixelPoint GetVertex(int index)
        {
            if (index < 0 || index >= _vertices.Count)
                throw new ArgumentOutOfRangeException(nameof(index));
            
            return _vertices[index];
        }

        /// <summary>
        /// Obtiene una arista del pol�gono (par de v�rtices consecutivos).
        /// </summary>
        public Tuple<PixelPoint, PixelPoint> GetEdge(int index)
        {
            if (index < 0 || index >= _vertices.Count)
                throw new ArgumentOutOfRangeException(nameof(index));
            
            var start = _vertices[index];
            var end = _vertices[(index + 1) % _vertices.Count];
            return new Tuple<PixelPoint, PixelPoint>(start, end);
        }

        /// <summary>
        /// Limpia todos los v�rtices del pol�gono.
        /// </summary>
        public void Clear()
        {
            _vertices.Clear();
        }

        /// <summary>
        /// Verifica si el pol�gono es v�lido (tiene al menos 3 v�rtices).
        /// </summary>
        public bool IsValid()
        {
            return _vertices.Count >= 3;
        }

        public override string ToString()
        {
            return $"Polygon[{_vertices.Count} vertices]";
        }
    }
}
