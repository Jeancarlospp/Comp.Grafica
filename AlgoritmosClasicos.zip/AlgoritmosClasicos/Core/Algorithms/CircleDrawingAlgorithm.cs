using System;
using System.Collections.Generic;
using AlgoritmosClasicos.Core.Interfaces;
using AlgoritmosClasicos.Core.Models;

namespace AlgoritmosClasicos.Core.Algorithms
{
    /// <summary>
    /// Clase base abstracta para todos los algoritmos de trazado de c�rculos.
    /// Contiene l�gica com�n de validaci�n y m�todos auxiliares reutilizables.
    /// </summary>
    public abstract class CircleDrawingAlgorithm : ICircleDrawingAlgorithm
    {
        public abstract string Name { get; }
        public abstract string Description { get; }

        /// <summary>
        /// M�todo plantilla que valida las entradas y ejecuta el algoritmo espec�fico.
        /// </summary>
        public List<PixelPoint> CalculateCircle(PixelPoint center, int radius)
        {
            // Validar entradas
            ValidateInputs(center, radius);

            // Si el radio es 0, retornar solo el centro
            if (radius == 0)
            {
                return new List<PixelPoint> { center };
            }

            // Ejecutar el algoritmo espec�fico
            return CalculateCircleImplementation(center, radius);
        }

        /// <summary>
        /// M�todo abstracto que cada algoritmo concreto debe implementar.
        /// </summary>
        protected abstract List<PixelPoint> CalculateCircleImplementation(PixelPoint center, int radius);

        /// <summary>
        /// Valida que el centro no sea nulo y que el radio sea v�lido.
        /// </summary>
        protected virtual void ValidateInputs(PixelPoint center, int radius)
        {
            if (center == null)
                throw new ArgumentNullException(nameof(center), "El centro del c�rculo no puede ser nulo.");

            if (radius < 0)
                throw new ArgumentException("El radio no puede ser negativo.", nameof(radius));

            const int MAX_RADIUS = 1000;
            if (radius > MAX_RADIUS)
                throw new ArgumentException($"El radio excede el m�ximo permitido ({MAX_RADIUS}).", nameof(radius));

            // Validar que las coordenadas del centro est�n en un rango razonable
            const int MAX_COORDINATE = 10000;
            if (Math.Abs(center.X) > MAX_COORDINATE || Math.Abs(center.Y) > MAX_COORDINATE)
                throw new ArgumentException("Las coordenadas del centro est�n fuera del rango permitido.");
        }

        /// <summary>
        /// Agrega los 8 puntos sim�tricos de un c�rculo dado un punto (x, y) relativo al centro.
        /// Esto aprovecha la simetr�a de 8 v�as del c�rculo.
        /// </summary>
        protected void AddSymmetricPoints(List<PixelPoint> points, PixelPoint center, int x, int y)
        {
            // Los 8 puntos sim�tricos son:
            // (x, y), (y, x), (-x, y), (-y, x), (x, -y), (y, -x), (-x, -y), (-y, -x)
            
            points.Add(new PixelPoint(center.X + x, center.Y + y));  // Octante 1
            points.Add(new PixelPoint(center.X + y, center.Y + x));  // Octante 2
            points.Add(new PixelPoint(center.X - y, center.Y + x));  // Octante 3
            points.Add(new PixelPoint(center.X - x, center.Y + y));  // Octante 4
            points.Add(new PixelPoint(center.X - x, center.Y - y));  // Octante 5
            points.Add(new PixelPoint(center.X - y, center.Y - x));  // Octante 6
            points.Add(new PixelPoint(center.X + y, center.Y - x));  // Octante 7
            points.Add(new PixelPoint(center.X + x, center.Y - y));  // Octante 8
        }

        /// <summary>
        /// Calcula el valor absoluto de un n�mero.
        /// </summary>
        protected int Abs(int value)
        {
            return value < 0 ? -value : value;
        }

        /// <summary>
        /// Ordena los puntos del c�rculo en sentido horario comenzando desde el punto m�s a la derecha.
        /// Esto es �til para la visualizaci�n paso a paso.
        /// </summary>
        protected List<PixelPoint> SortPointsClockwise(List<PixelPoint> points, PixelPoint center)
        {
            // Calcular el �ngulo de cada punto respecto al centro
            var pointsWithAngle = new List<(PixelPoint point, double angle)>();
            
            foreach (var point in points)
            {
                int dx = point.X - center.X;
                int dy = point.Y - center.Y;
                double angle = Math.Atan2(dy, dx);
                pointsWithAngle.Add((point, angle));
            }

            // Ordenar por �ngulo
            pointsWithAngle.Sort((a, b) => a.angle.CompareTo(b.angle));

            // Extraer solo los puntos
            var sortedPoints = new List<PixelPoint>();
            foreach (var item in pointsWithAngle)
            {
                sortedPoints.Add(item.point);
            }

            return sortedPoints;
        }
    }
}
