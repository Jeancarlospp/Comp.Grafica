using System.Collections.Generic;
using AlgoritmosClasicos.Core.Algorithms;
using AlgoritmosClasicos.Core.Models;

namespace AlgoritmosClasicos.Algorithms.CircleDrawing
{
    /// <summary>
    /// Implementaci�n del algoritmo Incremental (Punto Medio) para trazado de c�rculos.
    /// 
    /// FUNCIONAMIENTO:
    /// - Basado en la ecuaci�n impl�cita del c�rculo: x� + y� - r� = 0
    /// - Eval�a el punto medio entre dos p�xeles candidatos.
    /// - Usa un par�metro de decisi�n para elegir el p�xel m�s cercano al c�rculo ideal.
    /// - Utiliza solo aritm�tica entera para eficiencia.
    /// - Aprovecha la simetr�a de 8 v�as del c�rculo.
    /// - Similar a Bresenham pero basado en la ecuaci�n del c�rculo.
    /// </summary>
    public class IncrementalCircleAlgorithm : CircleDrawingAlgorithm
    {
        public override string Name => "Incremental (Punto Medio)";

        public override string Description =>
            "Algoritmo basado en la ecuaci�n impl�cita del c�rculo. Eval�a el punto medio entre " +
            "p�xeles candidatos usando un par�metro de decisi�n incremental. Utiliza aritm�tica " +
            "entera y la simetr�a de 8 v�as para eficiencia.";

        protected override List<PixelPoint> CalculateCircleImplementation(PixelPoint center, int radius)
        {
            var points = new List<PixelPoint>();

            int x = 0;
            int y = radius;

            int p = 1 - radius;

            AddSymmetricPoints(points, center, x, y);

            while (x < y)
            {
                x++;

                if (p < 0)
                {
                    p = p + 2 * x + 1;
                }
                else
                {
                    y--;
                    p = p + 2 * (x - y) + 1;
                }

                AddSymmetricPoints(points, center, x, y);
            }

            return SortPointsClockwise(points, center);
        }
    }
}
