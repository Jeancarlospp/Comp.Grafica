using System.Collections.Generic;
using AlgoritmosClasicos.Core.Algorithms;
using AlgoritmosClasicos.Core.Models;

namespace AlgoritmosClasicos.Algorithms.CircleDrawing
{
    /// <summary>
    /// Implementaci�n del algoritmo de Bresenham para trazado de c�rculos.
    /// 
    /// FUNCIONAMIENTO:
    /// - Utiliza solo aritm�tica entera para m�xima eficiencia.
    /// - Usa un par�metro de decisi�n para determinar los p�xeles a dibujar.
    /// - Aprovecha la simetr�a de 8 v�as del c�rculo (solo calcula 1/8 del c�rculo).
    /// - Es el algoritmo m�s eficiente para dibujar c�rculos por computadora.
    /// - El par�metro de decisi�n se actualiza incrementalmente en cada iteraci�n.
    /// </summary>
    public class BresenhamCircleAlgorithm : CircleDrawingAlgorithm
    {
        public override string Name => "Bresenham para C�rculos";

        public override string Description =>
            "Algoritmo eficiente que usa solo aritm�tica entera. Utiliza un par�metro de decisi�n " +
            "incremental y aprovecha la simetr�a de 8 v�as del c�rculo para calcular todos los " +
            "puntos dibujando solo un octavo del c�rculo.";

        protected override List<PixelPoint> CalculateCircleImplementation(PixelPoint center, int radius)
        {
            var points = new List<PixelPoint>();

            int x = 0;
            int y = radius;
   
            int d = 3 - 2 * radius;


            AddSymmetricPoints(points, center, x, y);
            while (x <= y)
            {
                x++;

                if (d > 0)
                {
                    y--;
                    d = d + 4 * (x - y) + 10;
                }
                else
                {
                    d = d + 4 * x + 6;
                }

                AddSymmetricPoints(points, center, x, y);
            }

            return SortPointsClockwise(points, center);
        }
    }
}
