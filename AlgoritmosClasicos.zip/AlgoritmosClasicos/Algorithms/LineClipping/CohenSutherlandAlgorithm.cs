using AlgoritmosClasicos.Core.Algorithms;
using AlgoritmosClasicos.Core.Models;

namespace AlgoritmosClasicos.Algorithms.LineClipping
{
    /// <summary>
    /// Implementaci�n del algoritmo de Cohen-Sutherland para recorte de l�neas.
    /// 
    /// FUNCIONAMIENTO:
    /// - Divide el espacio en 9 regiones usando c�digos de 4 bits.
    /// - Cada bit representa una posici�n relativa a la ventana (arriba, abajo, izquierda, derecha).
    /// - Utiliza operaciones l�gicas (AND, OR) para determinar aceptaci�n/rechazo r�pido.
    /// - Para l�neas que cruzan, calcula puntos de intersecci�n iterativamente.
    /// - Muy eficiente para casos triviales (completamente dentro o fuera).
    /// </summary>
    public class CohenSutherlandAlgorithm : LineClippingAlgorithm
    {
        // C�digos de regi�n
        private const int INSIDE = 0; // 0000
        private const int LEFT = 1;   // 0001
        private const int RIGHT = 2;  // 0010
        private const int BOTTOM = 4; // 0100
        private const int TOP = 8;    // 1000

        public override string Name => "Cohen-Sutherland";

        public override string Description =>
            "Algoritmo cl�sico de recorte de l�neas. Divide el espacio en 9 regiones usando c�digos de 4 bits. " +
            "Usa operaciones l�gicas para determinar aceptaci�n/rechazo r�pido. Calcula intersecciones iterativamente.";

        protected override ClippedLine ClipLineImplementation(PixelPoint start, PixelPoint end, ClipRectangle clipRect)
        {
            int x0 = start.X;
            int y0 = start.Y;
            int x1 = end.X;
            int y1 = end.Y;

            int code0 = ComputeCode(x0, y0, clipRect);
            int code1 = ComputeCode(x1, y1, clipRect);

            bool accept = false;

            while (true)
            {
                if ((code0 | code1) == 0)
                {
                    accept = true;
                    break;
                }
                else if ((code0 & code1) != 0)
                {
                    break;
                }
                else
                {
     
                    int x = 0, y = 0;

                    int codeOut = code0 != 0 ? code0 : code1;

                    if ((codeOut & TOP) != 0)
                    {
                        x = x0 + (x1 - x0) * (clipRect.YMax - y0) / (y1 - y0);
                        y = clipRect.YMax;
                    }
                    else if ((codeOut & BOTTOM) != 0)
                    {
                        x = x0 + (x1 - x0) * (clipRect.YMin - y0) / (y1 - y0);
                        y = clipRect.YMin;
                    }
                    else if ((codeOut & RIGHT) != 0)
                    {
                        y = y0 + (y1 - y0) * (clipRect.XMax - x0) / (x1 - x0);
                        x = clipRect.XMax;
                    }
                    else if ((codeOut & LEFT) != 0)
                    {
                        y = y0 + (y1 - y0) * (clipRect.XMin - x0) / (x1 - x0);
                        x = clipRect.XMin;
                    }

                    if (codeOut == code0)
                    {
                        x0 = x;
                        y0 = y;
                        code0 = ComputeCode(x0, y0, clipRect);
                    }
                    else
                    {
                        x1 = x;
                        y1 = y;
                        code1 = ComputeCode(x1, y1, clipRect);
                    }
                }
            }

            if (accept)
            {
                return new ClippedLine(new PixelPoint(x0, y0), new PixelPoint(x1, y1));
            }
            else
            {
                return ClippedLine.NotVisible();
            }
        }

        private int ComputeCode(int x, int y, ClipRectangle clipRect)
        {
            int code = INSIDE;

            if (x < clipRect.XMin)
                code |= LEFT;
            else if (x > clipRect.XMax)
                code |= RIGHT;

            if (y < clipRect.YMin)
                code |= BOTTOM;
            else if (y > clipRect.YMax)
                code |= TOP;

            return code;
        }
    }
}
