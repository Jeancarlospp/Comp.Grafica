using System;
using System.Collections.Generic;
using AlgoritmosClasicos.Core.Algorithms;
using AlgoritmosClasicos.Core.Models;

namespace AlgoritmosClasicos.Algorithms.PolygonClipping
{
    /// <summary>
    /// Implementaci�n REAL del algoritmo de Cyrus-Beck para recorte de pol�gonos.
    /// 
    /// FUNCIONAMIENTO:
    /// - Usa normales de bordes y producto punto para determinar visibilidad.
    /// - Recorta cada arista del pol�gono contra cada borde de la ventana.
    /// - Calcula par�metros t de entrada y salida usando producto punto.
    /// - Funciona con CUALQUIER pol�gono convexo como ventana (no solo rect�ngulos).
    /// 
    /// VENTAJAS:
    /// - Generalizable a ventanas de cualquier forma convexa.
    /// - Conceptualmente elegante (usa geometr�a vectorial).
    /// - Demuestra versatilidad con tri�ngulos, pent�gonos, etc.
    /// </summary>
    public class CyrusBeckAlgorithm : PolygonClippingAlgorithm
    {
        public override string Name => "Cyrus-Beck";

        public override string Description =>
            "Algoritmo vers�til basado en normales de bordes y producto punto. " +
            "Funciona con CUALQUIER pol�gono convexo como ventana de recorte, " +
            "no solo rect�ngulos. Demuestra su poder con formas triangulares.";

        protected override Polygon ClipPolygonImplementation(Polygon subjectPolygon, ClipRectangle clipRectangle)
        {
            var clipShape = ClipShape.FromRectangle(clipRectangle);
            return ClipPolygonAgainstShape(subjectPolygon, clipShape);
        }

        public Polygon ClipPolygonAgainstShape(Polygon subjectPolygon, ClipShape clipShape)
        {
            List<PixelPoint> clippedVertices = new List<PixelPoint>();

            for (int i = 0; i < subjectPolygon.VertexCount; i++)
            {
                var edge = subjectPolygon.GetEdge(i);
                var clippedEdge = ClipEdgeCyrusBeck(edge.Item1, edge.Item2, clipShape);

                if (clippedEdge != null)
                {
                    if (clippedVertices.Count == 0 || 
                        !clippedVertices[clippedVertices.Count - 1].Equals(clippedEdge.Item1))
                    {
                        clippedVertices.Add(clippedEdge.Item1);
                    }

                    if (!clippedEdge.Item1.Equals(clippedEdge.Item2))
                    {
                        clippedVertices.Add(clippedEdge.Item2);
                    }
                }
            }

            clippedVertices = RemoveConsecutiveDuplicates(clippedVertices);

            if (clippedVertices.Count < 3)
                return null;

            return new Polygon(clippedVertices);
        }

        private Tuple<PixelPoint, PixelPoint> ClipEdgeCyrusBeck(PixelPoint p1, PixelPoint p2, ClipShape clipShape)
        {
            float x1 = p1.X;
            float y1 = p1.Y;
            float x2 = p2.X;
            float y2 = p2.Y;

            float dx = x2 - x1;
            float dy = y2 - y1;

            float tEnter = 0.0f;
            float tExit = 1.0f;

            for (int i = 0; i < clipShape.VertexCount; i++)
            {
                var edge = clipShape.GetEdge(i);
                var edgeStart = edge.Start;
                var edgeEnd = edge.End;

                float edgeDx = edgeEnd.X - edgeStart.X;
                float edgeDy = edgeEnd.Y - edgeStart.Y;

                float normalX = -edgeDy;
                float normalY = edgeDx;

                float wx = x1 - edgeStart.X;
                float wy = y1 - edgeStart.Y;

                float dotProduct = dx * normalX + dy * normalY;

                float dotProductW = wx * normalX + wy * normalY;

                if (dotProduct == 0)
                {
                    if (dotProductW < 0)
                    {
                        return null;
                    }
                }
                else
                {
                    float t = -dotProductW / dotProduct;

                    if (dotProduct < 0)
                    {
                        tEnter = Math.Max(tEnter, t);
                    }
                    else
                    {
                        tExit = Math.Min(tExit, t);
                    }
                }
            }

            if (tEnter > tExit)
            {
                return null;
            }

            int clippedX1 = (int)Math.Round(x1 + tEnter * dx);
            int clippedY1 = (int)Math.Round(y1 + tEnter * dy);
            int clippedX2 = (int)Math.Round(x1 + tExit * dx);
            int clippedY2 = (int)Math.Round(y1 + tExit * dy);

            return new Tuple<PixelPoint, PixelPoint>(
                new PixelPoint(clippedX1, clippedY1),
                new PixelPoint(clippedX2, clippedY2)
            );
        }


        private List<PixelPoint> RemoveConsecutiveDuplicates(List<PixelPoint> vertices)
        {
            if (vertices.Count == 0)
                return vertices;

            List<PixelPoint> result = new List<PixelPoint>();
            result.Add(vertices[0]);

            for (int i = 1; i < vertices.Count; i++)
            {
                if (!vertices[i].Equals(vertices[i - 1]))
                {
                    result.Add(vertices[i]);
                }
            }

            // Verificar el �ltimo con el primero
            if (result.Count > 1 && result[result.Count - 1].Equals(result[0]))
            {
                result.RemoveAt(result.Count - 1);
            }

            return result;
        }
    }
}
